function HomePage() {
  return (
    <>
      <div className="center">
        <h1>Home Page</h1>
      </div>
    </>
  );
}

export default HomePage;
